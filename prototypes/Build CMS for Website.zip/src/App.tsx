import { useMemo, useState, type ReactNode } from "react";

type IconName =
  | "home"
  | "pages"
  | "edit"
  | "image"
  | "inbox"
  | "users"
  | "settings"
  | "external"
  | "plus"
  | "search"
  | "chevron"
  | "arrow"
  | "more"
  | "check"
  | "clock"
  | "sparkles"
  | "grid"
  | "workflow"
  | "globe"
  | "chart"
  | "code"
  | "target"
  | "shield"
  | "menu"
  | "close";

const paths: Record<IconName, ReactNode> = {
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10" /><path d="M9 20v-6h6v6" /></>,
  pages: <><path d="M6 3h9l3 3v15H6z" /><path d="M15 3v4h4" /><path d="M9 11h6M9 15h6" /></>,
  edit: <><path d="m4 20 4.5-1 10-10a2.1 2.1 0 0 0-3-3l-10 10z" /><path d="m14 7 3 3" /></>,
  image: <><rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="9" cy="10" r="2" /><path d="m3 17 5-4 4 3 3-2 6 5" /></>,
  inbox: <><path d="M4 5h16l2 10v4H2v-4z" /><path d="M2 15h5l2 3h6l2-3h5" /></>,
  users: <><path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M17 11a4 4 0 0 1 5 4v2" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19 13.5v-3l-2-.7-.7-1.7.9-1.9-2.1-2.1-1.9.9-1.7-.7-.7-2h-3l-.7 2-1.7.7-1.9-.9-2.1 2.1.9 1.9-.7 1.7-2 .7v3l2 .7.7 1.7-.9 1.9 2.1 2.1 1.9-.9 1.7.7.7 2h3l.7-2 1.7-.7 1.9.9 2.1-2.1-.9-1.9.7-1.7z" /></>,
  external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v7H4V6h7" /></>,
  plus: <path d="M12 5v14M5 12h14" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  chevron: <path d="m9 18 6-6-6-6" />,
  arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
  more: <><circle cx="5" cy="12" r=".7" fill="currentColor" /><circle cx="12" cy="12" r=".7" fill="currentColor" /><circle cx="19" cy="12" r=".7" fill="currentColor" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  sparkles: <><path d="m12 3 1.2 3.3L16.5 8l-3.3 1.2L12 12.5l-1.2-3.3L7.5 8l3.3-1.7z" /><path d="m18.5 14 .7 2 2 1-2 1-.7 2-.8-2-2-1 2-1zM5 14l.5 1.3L7 16l-1.5.7L5 18l-.5-1.3L3 16l1.5-.7z" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
  workflow: <><rect x="3" y="3" width="6" height="5" rx="1" /><rect x="15" y="16" width="6" height="5" rx="1" /><path d="M9 5.5h4a4 4 0 0 1 4 4v6.5M15 18.5h-4a4 4 0 0 1-4-4V8" /></>,
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></>,
  chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></>,
  code: <path d="m8 9-3 3 3 3m8-6 3 3-3 3m-3-9-2 12" />,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
  shield: <><path d="M12 3 4 6v5c0 5 3.5 8.5 8 10 4.5-1.5 8-5 8-10V6z" /><path d="m9 12 2 2 4-4" /></>,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

const navGroups = [
  {
    label: "Workspace",
    items: [
      { label: "Overview", icon: "home" as IconName },
      { label: "Visual builder", icon: "grid" as IconName },
      { label: "Content", icon: "edit" as IconName },
      { label: "Media library", icon: "image" as IconName },
    ],
  },
  {
    label: "Grow",
    items: [
      { label: "Leads & CRM", icon: "users" as IconName, count: 12 },
      { label: "Forms & automation", icon: "workflow" as IconName },
      { label: "SEO & personalization", icon: "target" as IconName },
      { label: "Analytics", icon: "chart" as IconName },
    ],
  },
  {
    label: "Platform",
    items: [
      { label: "Localization", icon: "globe" as IconName },
      { label: "Apps & API", icon: "code" as IconName },
      { label: "Workflow & access", icon: "shield" as IconName },
    ],
  },
];

const modules = {
  "Visual builder": {
    eyebrow: "Design",
    title: "Visual website builder",
    description: "Build responsive pages with reusable sections, global styles, and real-time previews—without touching code.",
    action: "Create a page",
    stats: [["28", "Published pages"], ["14", "Reusable sections"], ["3", "Active experiments"]],
    features: [
      ["Responsive canvas", "Design across desktop, tablet, and mobile breakpoints.", "grid"],
      ["Design system", "Manage global colors, typography, spacing, and components.", "sparkles"],
      ["Templates & symbols", "Reuse headers, forms, testimonials, and saved sections.", "pages"],
      ["Versions & branches", "Undo changes, compare versions, and merge campaigns.", "workflow"],
      ["Collaborative editing", "Edit together with live presence and page locking.", "users"],
      ["Component marketplace", "Install prebuilt sections, templates, and integrations.", "plus"],
    ],
  },
  Content: {
    eyebrow: "Content",
    title: "Structured content studio",
    description: "Model, create, relate, and publish content to every website and app from one workspace.",
    action: "New entry",
    stats: [["9", "Collections"], ["246", "Content entries"], ["18", "Awaiting review"]],
    features: [
      ["Custom collections", "Build Services, Locations, FAQs, Posts, Team, and Pricing.", "edit"],
      ["Content graph", "Visualize relationships between services, cities, and pages.", "workflow"],
      ["AI content assistant", "Draft, rewrite, translate, and optimize in your brand voice.", "sparkles"],
      ["Scheduled publishing", "Coordinate launches with calendars and release bundles.", "clock"],
      ["Multi-channel content", "Publish once to websites, mobile apps, and displays.", "globe"],
      ["Content health", "Find stale, missing, duplicate, and underperforming content.", "check"],
    ],
  },
  "Media library": {
    eyebrow: "Assets",
    title: "Intelligent media library",
    description: "Organize, optimize, transform, and track every image, video, document, and brand asset.",
    action: "Upload media",
    stats: [["1,284", "Assets"], ["8.4 GB", "Storage used"], ["96%", "Optimized"]],
    features: [
      ["Smart organization", "Use folders, tags, filters, and AI-powered visual search.", "search"],
      ["Image transforms", "Resize, crop, set focal points, and optimize automatically.", "image"],
      ["Usage tracking", "See every page and app where an asset appears.", "target"],
      ["Replace everywhere", "Update an asset across every channel in one click.", "workflow"],
      ["Rights management", "Track ownership, usage rights, and expiration dates.", "shield"],
      ["Duplicate detection", "Keep your library clean and reduce storage usage.", "check"],
    ],
  },
  "Leads & CRM": {
    eyebrow: "Moving operations",
    title: "Lead and quote pipeline",
    description: "Turn website inquiries into booked moves with a purpose-built sales and operations workspace.",
    action: "Add lead",
    stats: [["184", "Open leads"], ["32", "Moves this week"], ["$84k", "Pipeline value"]],
    features: [
      ["Quote pipeline", "Track inquiries from new lead to estimate, booking, and move.", "target"],
      ["Move calendar", "Coordinate move dates, crews, trucks, and availability.", "clock"],
      ["Service areas", "Manage cities, ZIP codes, travel fees, and local coverage.", "globe"],
      ["Cost calculator", "Build dynamic estimates from inventory, distance, and services.", "chart"],
      ["Customer portal", "Share quotes, schedules, documents, updates, and payments.", "users"],
      ["Reviews & follow-up", "Automate review requests and lead follow-up sequences.", "sparkles"],
    ],
  },
  "Forms & automation": {
    eyebrow: "Automation",
    title: "Forms and automated workflows",
    description: "Capture better leads and connect every submission to the tools your team already uses.",
    action: "Build a form",
    stats: [["12", "Live forms"], ["2,491", "Submissions"], ["18", "Active workflows"]],
    features: [
      ["Visual form builder", "Create multi-step forms with logic, uploads, and validation.", "grid"],
      ["Workflow builder", "Trigger emails, assignments, webhooks, and CRM updates.", "workflow"],
      ["Submission inbox", "Review, filter, assign, export, and retain responses securely.", "inbox"],
      ["Integrations", "Connect Zapier, Make, HubSpot, Salesforce, Slack, and email.", "plus"],
      ["Spam protection", "Block abuse with smart filtering and verification controls.", "shield"],
      ["Customer messages", "Send personalized confirmations and status updates.", "users"],
    ],
  },
  "SEO & personalization": {
    eyebrow: "Growth",
    title: "SEO and personalization",
    description: "Improve search visibility and deliver the most relevant experience to every visitor.",
    action: "Run site audit",
    stats: [["92", "SEO health"], ["164", "Keywords tracked"], ["6", "Audience segments"]],
    features: [
      ["SEO control center", "Manage metadata, canonicals, sitemaps, schema, and indexing.", "target"],
      ["Redirect manager", "Create redirects and automatically detect broken links.", "workflow"],
      ["Programmatic pages", "Generate optimized service and location landing pages.", "pages"],
      ["Audience segments", "Personalize content by location, campaign, and behavior.", "users"],
      ["A/B testing", "Test headlines, calls to action, forms, and page sections.", "chart"],
      ["Social previews", "Preview and tailor how every page appears when shared.", "external"],
    ],
  },
  Analytics: {
    eyebrow: "Insights",
    title: "Content and growth analytics",
    description: "Understand performance from the first visit through quote request, booking, and revenue.",
    action: "Create report",
    stats: [["12.8k", "Monthly visitors"], ["4.8%", "Conversion rate"], ["$42", "Cost per lead"]],
    features: [
      ["Performance overview", "Monitor traffic, conversions, revenue, and content trends.", "chart"],
      ["Form funnels", "Find where visitors drop out of multi-step quote forms.", "workflow"],
      ["Content insights", "Compare pages by traffic, engagement, leads, and freshness.", "pages"],
      ["Attribution", "Connect bookings to campaigns, channels, and landing pages.", "target"],
      ["Custom dashboards", "Build role-specific reports using the metrics that matter.", "grid"],
      ["Smart alerts", "Get notified when traffic, leads, or performance changes.", "sparkles"],
    ],
  },
  Localization: {
    eyebrow: "Global",
    title: "Localization workspace",
    description: "Manage multilingual and regional content with clear translation and publishing workflows.",
    action: "Add locale",
    stats: [["4", "Locales"], ["87%", "Translated"], ["12", "Needs review"]],
    features: [
      ["Translation editor", "Edit source and translated content side-by-side.", "globe"],
      ["Locale publishing", "Review and publish languages independently.", "check"],
      ["Regional content", "Adapt prices, services, contact details, and promotions.", "target"],
      ["Translation AI", "Generate contextual translations in your brand voice.", "sparkles"],
      ["Progress dashboard", "Track missing, outdated, and reviewed translations.", "chart"],
      ["Localized SEO", "Manage locale URLs, metadata, hreflang, and redirects.", "search"],
    ],
  },
  "Apps & API": {
    eyebrow: "Developers",
    title: "Headless content platform",
    description: "Deliver content to any website, mobile app, portal, kiosk, or digital product.",
    action: "Create API key",
    stats: [["2.4m", "API requests"], ["8", "Connected apps"], ["99.99%", "Uptime"]],
    features: [
      ["Content APIs", "Use REST, GraphQL, preview APIs, and generated SDKs.", "code"],
      ["Webhooks", "Notify connected systems when content or assets change.", "workflow"],
      ["Environments", "Separate development, staging, and production content.", "grid"],
      ["Access tokens", "Create scoped keys with usage and security controls.", "shield"],
      ["Import & export", "Move structured data with CSV, JSON, and migration tools.", "external"],
      ["Global delivery", "Serve optimized content through a fast edge CDN.", "globe"],
    ],
  },
  "Workflow & access": {
    eyebrow: "Governance",
    title: "Workflow, roles, and governance",
    description: "Give every teammate the access they need while keeping publishing safe and accountable.",
    action: "Invite teammate",
    stats: [["6", "Team members"], ["4", "Custom roles"], ["21", "Pending tasks"]],
    features: [
      ["Approval workflows", "Move work through draft, review, approved, and published.", "workflow"],
      ["Roles & permissions", "Control access by workspace, locale, content type, and action.", "shield"],
      ["Assignments", "Set owners, reviewers, due dates, and notifications.", "users"],
      ["Audit history", "Review every content, settings, and access change.", "clock"],
      ["Version recovery", "Compare changes and restore any previous version.", "pages"],
      ["Brand guardrails", "Keep layouts, styles, language, and assets on brand.", "check"],
    ],
  },
} satisfies Record<string, { eyebrow: string; title: string; description: string; action: string; stats: string[][]; features: string[][] }>;

const pageRows = [
  { name: "Home", path: "/", status: "Published", updated: "12 min ago", initials: "KM", color: "violet" },
  { name: "Local Moving", path: "/services/local-moving", status: "Published", updated: "Yesterday", initials: "KM", color: "blue" },
  { name: "Long Distance Moving", path: "/services/long-distance", status: "Draft", updated: "2 days ago", initials: "AR", color: "orange" },
  { name: "Moving Resources", path: "/resources", status: "Published", updated: "Jun 18", initials: "AR", color: "teal" },
];

function ModuleView({ name, notify }: { name: string; notify: (message: string) => void }) {
  const module = modules[name as keyof typeof modules];

  if (!module) {
    return (
      <section className="module-page">
        <div className="module-hero">
          <div>
            <span className="eyebrow">Workspace</span>
            <h1>{name}</h1>
            <p>Manage your workspace preferences, members, and account configuration.</p>
          </div>
          <button className="primary-button" onClick={() => notify(`${name} settings saved`)}>Save changes</button>
        </div>
      </section>
    );
  }

  return (
    <section className="module-page">
      <div className="module-hero">
        <div>
          <span className="eyebrow">{module.eyebrow}</span>
          <h1>{module.title}</h1>
          <p>{module.description}</p>
        </div>
        <button className="primary-button" onClick={() => notify(`${module.action} opened`)}><Icon name="plus" size={17} />{module.action}</button>
      </div>

      <div className="module-stats">
        {module.stats.map(([value, label]) => (
          <article key={label}><strong>{value}</strong><span>{label}</span><em><Icon name="arrow" size={14} /></em></article>
        ))}
      </div>

      <div className="section-title">
        <div><h2>Everything you need</h2><p>Powerful tools, ready for your team to use.</p></div>
        <span className="enabled-pill"><i />All systems enabled</span>
      </div>
      <div className="feature-grid">
        {module.features.map(([title, description, icon], index) => (
          <button className="feature-card" key={title} onClick={() => notify(`${title} opened`)}>
            <span className={`feature-icon tone-${(index % 4) + 1}`}><Icon name={icon as IconName} /></span>
            <span className="feature-copy"><strong>{title}</strong><small>{description}</small></span>
            <span className="feature-arrow"><Icon name="arrow" size={16} /></span>
          </button>
        ))}
      </div>

      <div className="module-footer panel">
        <div className="module-footer-icon"><Icon name="sparkles" /></div>
        <div><strong>Built to work together</strong><p>This module is connected to your content, analytics, automations, and publishing workflow.</p></div>
        <button className="preview-button" onClick={() => notify("Documentation opened")}>View documentation <Icon name="external" size={14} /></button>
      </div>
    </section>
  );
}

export default function App() {
  const [active, setActive] = useState("Overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState("");
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState("");

  const visiblePages = useMemo(
    () => pageRows.filter((page) => page.name.toLowerCase().includes(query.toLowerCase())),
    [query],
  );

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2400);
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><span /><span /><span /></div>
          <span>Mono</span>
          <button className="mobile-close" onClick={() => setMenuOpen(false)} aria-label="Close navigation"><Icon name="close" /></button>
        </div>

        <button className="site-switcher" onClick={() => notify("Workspace switcher opened")}>
          <div className="site-logo">S</div>
          <div><strong>SwiftMove</strong><span>swiftmove.com</span></div>
          <Icon name="chevron" size={15} />
        </button>

        <nav className="main-nav" aria-label="Main navigation">
          {navGroups.map((group) => (
            <div className="nav-group" key={group.label}>
              <span className="nav-label">{group.label}</span>
              {group.items.map((item) => (
                <button
                  className={`nav-item ${active === item.label ? "active" : ""}`}
                  key={item.label}
                  onClick={() => { setActive(item.label); setMenuOpen(false); }}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {item.count && <b>{item.count}</b>}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <button className="nav-item" onClick={() => setActive("Team")}><Icon name="users" /><span>Team</span></button>
          <button className="nav-item" onClick={() => setActive("Settings")}><Icon name="settings" /><span>Settings</span></button>
          <div className="plan-card">
            <span>Workspace plan</span>
            <strong>Business</strong>
            <div className="plan-bar"><i /></div>
            <small>6 of 10 team seats used</small>
          </div>
          <div className="user">
            <div className="avatar">KM</div>
            <div><strong>Katie Miller</strong><span>Admin</span></div>
            <button aria-label="User options"><Icon name="more" /></button>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="menu-button" onClick={() => setMenuOpen(true)} aria-label="Open navigation"><Icon name="menu" /></button>
          <div className="breadcrumbs"><span>SwiftMove</span><Icon name="chevron" size={14} /><strong>{active}</strong></div>
          <div className="top-actions">
            <button className="icon-button" onClick={() => setCommandOpen(true)} aria-label="Search"><Icon name="search" /></button>
            <button className="preview-button" onClick={() => notify("Opening website preview")}><Icon name="external" size={16} />View website</button>
            <button className="primary-button" onClick={() => notify("New content draft created")}><Icon name="plus" size={17} />Create new</button>
          </div>
        </header>

        <div className="content">
          {active === "Overview" ? (
          <>
          <section className="welcome">
            <div>
              <span className="eyebrow">Wednesday, June 25</span>
              <h1>Good morning, Katie</h1>
              <p>Here’s what’s happening with your website today.</p>
            </div>
            <button className="mobile-create" onClick={() => notify("New content draft created")}><Icon name="plus" />Create new</button>
          </section>

          <section className="metrics">
            <article className="metric">
              <div className="metric-top"><span>Website visits</span><em className="trend">+18.2%</em></div>
              <strong>12,840</strong>
              <small>vs. 10,862 last month</small>
              <div className="sparkline">
                <svg viewBox="0 0 160 40" preserveAspectRatio="none"><path d="M0 34 C15 33, 18 25, 34 28 S57 37, 67 21 S92 20, 101 24 S119 14, 128 18 S147 4, 160 7" /></svg>
              </div>
            </article>
            <article className="metric">
              <div className="metric-top"><span>Quote requests</span><em className="trend">+8.4%</em></div>
              <strong>184</strong>
              <small>14 new since yesterday</small>
              <div className="metric-footer"><div className="stacked-avatars"><i>JT</i><i>LP</i><i>+12</i></div><button onClick={() => notify("Showing quote requests")}>View leads <Icon name="arrow" size={14} /></button></div>
            </article>
            <article className="metric">
              <div className="metric-top"><span>Conversion rate</span><em className="trend">+1.1%</em></div>
              <strong>4.8%</strong>
              <small>Industry average is 3.2%</small>
              <div className="progress-track"><i /></div>
            </article>
            <article className="metric health-card">
              <div className="metric-top"><span>Website health</span><i className="live-dot">Live</i></div>
              <strong>Excellent</strong>
              <small>All systems are running smoothly</small>
              <div className="health-row"><span><Icon name="check" size={14} />Domain</span><span><Icon name="check" size={14} />SSL</span><span><Icon name="check" size={14} />Forms</span></div>
            </article>
          </section>

          <section className="dashboard-grid">
            <div className="panel pages-panel">
              <div className="panel-heading">
                <div><h2>Pages</h2><p>Manage and update your website pages.</p></div>
                <button className="text-button" onClick={() => setActive("Visual builder")}>View all pages <Icon name="arrow" size={15} /></button>
              </div>
              <div className="table-tools">
                <label className="search-field"><Icon name="search" size={16} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search pages..." /></label>
                <button className="filter-button">All pages <Icon name="chevron" size={14} /></button>
              </div>
              <div className="page-table">
                <div className="table-head"><span>Page</span><span>Status</span><span>Last updated</span><span /></div>
                {visiblePages.map((page) => (
                  <div className="table-row" key={page.name}>
                    <div className="page-name"><div className={`page-icon ${page.color}`}><Icon name="pages" size={16} /></div><div><strong>{page.name}</strong><span>{page.path}</span></div></div>
                    <div><span className={`status ${page.status.toLowerCase()}`}>{page.status}</span></div>
                    <div className="updated"><i className={`mini-avatar ${page.color}`}>{page.initials}</i><span>{page.updated}</span></div>
                    <button className="row-action" onClick={() => notify(`Options for ${page.name}`)} aria-label={`Options for ${page.name}`}><Icon name="more" /></button>
                  </div>
                ))}
                {visiblePages.length === 0 && <div className="empty-state">No pages match “{query}”.</div>}
              </div>
            </div>

            <aside className="right-column">
              <div className="panel quick-panel">
                <div className="panel-heading"><div><h2>Quick actions</h2><p>Keep your website up to date.</p></div></div>
                <button onClick={() => notify("Page editor opened")}><span className="quick-icon purple"><Icon name="plus" /></span><span><strong>Add a new page</strong><small>Create a landing page or service</small></span><Icon name="chevron" size={16} /></button>
                <button onClick={() => notify("Media library opened")}><span className="quick-icon blue"><Icon name="image" /></span><span><strong>Upload media</strong><small>Add images, videos or files</small></span><Icon name="chevron" size={16} /></button>
                <button onClick={() => notify("AI writing assistant opened")}><span className="quick-icon yellow"><Icon name="sparkles" /></span><span><strong>Write with AI</strong><small>Draft or improve your content</small></span><Icon name="chevron" size={16} /></button>
              </div>

              <div className="panel activity-panel">
                <div className="panel-heading"><div><h2>Recent activity</h2></div><button className="row-action"><Icon name="more" /></button></div>
                <div className="activity"><i className="activity-icon green"><Icon name="check" size={13} /></i><div><p><strong>Home</strong> was published</p><span><i className="mini-avatar violet">KM</i>Katie · 12 min ago</span></div></div>
                <div className="activity"><i className="activity-icon amber"><Icon name="edit" size={13} /></i><div><p><strong>Long Distance Moving</strong> edited</p><span><i className="mini-avatar orange">AR</i>Alex · 2 days ago</span></div></div>
                <div className="activity"><i className="activity-icon blue"><Icon name="inbox" size={13} /></i><div><p>New quote request from <strong>Jordan T.</strong></p><span><Icon name="clock" size={13} />3 days ago</span></div></div>
              </div>
            </aside>
          </section>
          </>
          ) : (
            <ModuleView name={active} notify={notify} />
          )}
        </div>
      </main>
      {menuOpen && <button className="scrim" onClick={() => setMenuOpen(false)} aria-label="Close navigation" />}
      {commandOpen && (
        <div className="command-backdrop" onClick={() => setCommandOpen(false)}>
          <div className="command-menu" onClick={(event) => event.stopPropagation()}>
            <label><Icon name="search" /><input autoFocus value={commandQuery} onChange={(event) => setCommandQuery(event.target.value)} placeholder="Search tools and features..." /><kbd>Esc</kbd></label>
            <span className="command-label">Jump to</span>
            <div className="command-results">
              {navGroups.flatMap((group) => group.items).filter((item) => item.label.toLowerCase().includes(commandQuery.toLowerCase())).map((item) => (
                <button key={item.label} onClick={() => { setActive(item.label); setCommandOpen(false); setCommandQuery(""); }}>
                  <span><Icon name={item.icon} /></span>{item.label}<Icon name="arrow" size={15} />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
      <div className={`toast ${toast ? "show" : ""}`}><Icon name="check" size={16} />{toast}</div>
    </div>
  );
}
